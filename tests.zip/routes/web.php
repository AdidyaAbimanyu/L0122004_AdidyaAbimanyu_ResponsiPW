<?php

use App\Http\Controllers\PegawaiController;
use Illuminate\Support\Facades\Route;

Route::get('/', [PegawaiController::class, 'home'])->name('home');
Route::get('/view', [PegawaiController::class, 'index'])->name('index');

Route::get('/add', [PegawaiController::class, 'tambah'])->name('tambah');
Route::post('/add/store', [PegawaiController::class, 'store'])->name('store');

Route::get('/edit{id}', [PegawaiController::class, 'edit'])->name('edit');
Route::post('/edit/update/{id}', [PegawaiController::class, 'update'])->name('update');

Route::get('/hapus/{id}', [PegawaiController::class, 'hapus'])->name('hapus');
Route::post('/hapus/destroy', [PegawaiController::class, 'destroy'])->name('destroy');

